<?php

    phpinfo();

?>
